//小误差PID，大误差pd
#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "LED.h"
#include "Timer.h"
#include "Motor.h"
#include "Key.h"
#include "Serial.h"
#include "Encoder.h"
#include "math.h"
uint16_t KeyNum;
int16_t Speed;
float Target, Actual,Out;
float Kp=0.4,Ki=0.1,Kd=0.2;
float error0,error1,errorInt;
int main(void)
{
	OLED_Init();
	Timer_Init();
	Key_Init();
	Motor_Init();
	Encoder_Init();
	Serial_Init();
	
	OLED_Printf(0,0,OLED_8X16,"Location Control");
	OLED_Update();
					
	while (1)
	{
		KeyNum=Key_GetNum();
		if(KeyNum==1){
			Target+=10;
			
		}
		
		
		OLED_Printf(0,16,OLED_8X16,"Target:%+04.0f",Target);
		OLED_Printf(0,32,OLED_8X16,"Actual:%+04.0f",Actual);
		OLED_Printf(0,48,OLED_8X16,"Out:%+04.0f",Out);
		OLED_Update();
		
		Serial_Printf("%f,%f,%f\r\n",Target,Actual,Out);
		
	}
}
void TIM1_UP_IRQHandler(void)
{
	static uint16_t Count;
	if (TIM_GetITStatus(TIM1, TIM_IT_Update) == SET)
	{
		Key_Tick();
		Count++;
		if(Count>=40)
		{
		Count=0;
		Speed+=Encoder_Get();
		Actual=Speed;
		error1=error0;
		error0=Target-Actual;
		if(fabs(error0)<50)
		{
			errorInt+=error0;
		}
		else{
			errorInt=0;
		}
		errorInt+=error0;
		Out=Kp*error0+Ki*errorInt+Kd*(error0-error1);
		if(Out==100){Out=100;}
		Motor_SetPWM(Out);
		}
		TIM_ClearITPendingBit(TIM1, TIM_IT_Update);
	}
}

