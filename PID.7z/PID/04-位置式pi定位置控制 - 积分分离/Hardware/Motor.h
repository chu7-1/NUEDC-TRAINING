#ifndef __MOTOR_H
#define __MOTOR_H

void Motor_Init(void);
void Motor_SetPWM(int8_t PWM);

#endif
